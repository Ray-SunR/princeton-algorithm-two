public class GameBetweenVertex {
    public int v;
    public int w;
    public GameBetweenVertex(int v, int w) {
        this.v = v;
        this.w = w;
    }
}
