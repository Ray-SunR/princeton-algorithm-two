/**
 * Created by renchen on 1/28/18.
 */
public class Coordinate {
    public Coordinate(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int x;
    public int y;
}
